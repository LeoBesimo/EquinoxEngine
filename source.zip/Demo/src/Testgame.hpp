#pragma once
#include <Equinox.hpp>

class Testgame : public eq::Application
{
private:
	
public:
	void update(float delta)
	{
		//OutputDebugString(L"Test\n");
	}

	void render()
	{
	}
};

